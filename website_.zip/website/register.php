<?php $title = "Register"; include('header.php'); include('db.php'); ?>
<div class="row py-5">
				<div class="col-12 col-lg-6 offset-lg-3">
					<div class="regback">
						<h2>Register </h2>
						<?php 
							if(isset($_POST["email"])) {
								$name = $_POST["name"];
								$email = $_POST["email"];
								$password = $_POST["password"];
								$phone = $_POST["phone"];
								$created_date = $_POST["created_date"];
								$sql = "INSERT INTO users (name, email, password, phone, created_date) VALUES ('$name', '$email', '$password', '$phone', '$created_date')";
								
							
								if (mysqli_query($conn, $sql)) {
										echo "You are registered successfully!";
									} else {
										echo "Error: " . $sql . "<br>" . mysqli_error($conn);
									}
									
									
							}
						?>
						
						<form action="register.php" method="post">
							<div class="form-group">
							<label for="exampleInputEmail1">Name</label>
							<input type="text" class="form-control" name="name">
						  </div>
						  <div class="form-group">
							<label for="exampleInputEmail1">Email address</label>
							<input type="email" class="form-control" name="email">
							<small class="form-text text-muted">We'll never share your email with anyone else.</small>
						  </div>
						  <div class="form-group">
							<label for="exampleInputPassword1">Password</label>
							<input type="password" class="form-control" name="password">
						  </div>
							<div class="form-group">
							<label for="exampleInputEmail1">Phone</label>
							<input type="text" class="form-control" name="phone">
						  </div>
							<input type="hidden" name="created_date" value="<?php echo date("Y-m-d"); ?>">
						  <button type="submit" class="rgbtn">Register</button>
						</form>
					</div>
				</div>
			</div>


<?php include('footer.php');?>