<!DOCTYPE html>
<html>
    <head>
    <title>Mproperty</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    </head>
<body>
    <div class="container"> 
        <header>
            <div class="logo">
                <h1>Mproperty</h1>
            </div>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#about">About us</a></li>
                <li><a href="#propertis">Properties</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#contact">Contact</a></li>
                <li><a href="login.php" class="active" id="logbtn">Login</a></li>
                <li><a href="register.php" class="active" id="logbtn">Register</a></li>
            </ul>
            
        </header>
        <!----------------secion------------->
        <section>
            <!-----------banner-------------->
            <div class="banner">
                
                <div class="search">
                    <h2>Find your dream home today</h2>
                    <p>Welcome to our website</p>
                    <form action="search.php" method="POST">
                        <input type="text" name="query" class="inpts" id="srch" required placeholder="Find your dream home">
						<input type="submit" class="rgbtn" value="Find"/>
                        
                    </form>
                </div>
             
                
            </div>
            <!---------------------About---------->
            <div id="about">
                <h2>About Us</h2>
           <div class="content">
               <div class="text">
                   <h3>Mproperty</h3>
                   <p>
                       Welcome to our website
                   </p>
                   <p>Mproperty is the only property solutions provider in Bangladesh. 
                   We cater to the needs of those seeking real estate services, with a 
                   promise to make property search, renting & buying easier than ever. We offer the easiest platform that enables anyone to buy, rent or sell properties in the country.
</p>
                 <a href="#">Read more</a>
               </div>
             
           <!-----------Partner------------------>
           <div class="partner">
               <h3>Our Partner</h3>

               <div class="thumb">
                <div class="thumb-box">
                    <img src="images/mamun3.jpg" alt="">
                    <h3>Project Manager</h3>
                    <h1>WALIULLAH</h1>
                    <div class="social">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-instagrm"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-linkedin"></i></a>
                    </div>
                    <p>Waliullah is currently pursuing his bachelor's degree,Department of Electrical and Computer Engineering,
                    at North South University.He is working as a Web Developer. </p>
                    <a href="#">Read more</a>
                </div>
                <div class="thumb-box">
                    <img src="images/sir.jpg" alt="">
                    <h3>CEO & Founder</h3>
                    <h3>Mahdy Rahman Chowdhury</h3>
                    <div class="social">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-instagrm"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-linkedin"></i></a>
                    </div>
                    <p>Mahdy Rahman Chowdhury (initial: Mdy) is currently working as an Associate Professor, Department of Electrical 
                    and Computer Engineering (full time) and Dept. of Math & Phys. at North South University, Dhaka, Bangladesh. 
                    Just after submitting his PhD thesis, he joined as an Assist. Professor 
                    at North South University, in January 2017. He has established a big research group & a research lab [NSU OPTICS LAB] at NSU:    https://sites.google.com/view/nsuopticslab/home</p>
                    <a href="#">Read more</a>
                </div>
                <div class="thumb-box">
                    <img src="images/khan.jpg" alt="">
                    <h3>Senior Agent</h3>
                    <h3>Khorshed Khan</h3>
                    <div class="social">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-instagrm"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-linkedin"></i></a>
                    </div>
                    <p>Khorshed Khan is currently pursuing his bachelor's degree,Department of Electrical and Computer Engineering,
                    at North South University</p>
                    <a href="#">Read more</a>
                </div>
               
            </div>
           </div>
            </div>
            <!--------------------Properties---------------->
            <div id="propertis">
                <h2>Hot Properties</h2>
                <div class="content">

<?php 
include('db.php');
	$query="SELECT * FROM property";
    $result = $conn->query($query);
	if($result->num_rows>0) {
        while($row = $result->fetch_assoc()) {
	?>
                    <div class="box">
                        <img src="images/<?php echo $row['photo']; ?>" alt="">
                        <div class="text">
                        <h3><?php echo $row['title']; ?></h3>
                        <span>BDT <?php echo $row['price']; ?></span>
						<?php if($row['type'] == 1) { ?>
                        <p>Find your best home</p>
                        <div class="details">
						
                            <span><?php echo $row['home_size']; ?></span>
                            <span><?php echo $row['home_bed']; ?> bedrooms</span>
                            <span><?php echo $row['home_bath']; ?> bathrooms</span>
						
                        </div>
						<?php } elseif($row['type'] == 2) { ?>
						<p>Office Space</p>
                        <div class="details">
						
                            <span><?php echo $row['office_size']; ?></span>
                            <span><?php echo $row['office_address']; ?> </span>
                            <span>&nbsp;</span>
						
                        </div>
						
						<?php } else { ?>
						<p>Land Property</p>
                        <div class="details">
						
                            <span><?php echo $row['land_size']; ?></span>
                            <span><?php echo $row['land_address']; ?> </span>
                            <span>&nbsp; </span>
						
                        </div>
						
						<?php }  ?>
                        <a href="property.php?id=<?php echo $row['id']; ?>">Read more</a>
                        </div>
                    </div>
					
                       
<?php  }} ?> 
                </div>
             
            </div>

            <!---------------------Services---------------->
             <div id="services">
                 <h2>OUR SERVICES</h2>
                 <p>Find your home</p>
                 <div class="content">
                     <div class="card">
                         <i class="fa fa-map-marker"></i>
                         <h3>Find Places Any Where IN BD</h3>
                     </div>
                    
                    <div class="card">
                        <i class="fa fa-map-users"></i>
                        <h3>We Have Agents With Experience</h3>
                    </div>
                    <div class="card">
                        <i class="fa fa-map-building"></i>
                        <h3>Buy Or Rent Sales Properties</h3>
                    </div>

                    <div class="card">
                        <i class="fa fa-map-mixcloud"></i>
                        <h3>Find Your New Place With Estate</h3>
                    </div>
                 </div>
              <div class="content">
                  <div class="card">
                      <img src="images/sc1.jpg">
                      <h3>Save The Money</h3>
                      <p>Find your home</p>
                  </div>
                  <div class="card">
                    <img src="images/sc2.jpg">
                    <h3>Cash Deposits</h3>
                    <p>Find your home</p>
                </div>

                <div class="card">
                    <img src="images/sc3.jpg">
                    <h3>Take your Key</h3>
                    <p>Find your home</p>
                </div>
              </div>
              

            <!----------------------Contact------------------>
            <div id="contact">
                <h2>Contact US</h2>
                <div class="content">
                    <form>
                        <input type="text" name="name" id="name" required placeholder="Your Name">
                        <input type="email" name="mail" id="mail" required placeholder="Your Email">
                        <input type="tel" name="tel" id="tel" required placeholder="Phone Number">
                        <textarea name="mess" id="mess" rows="7" placeholder="Your Message Here..."></textarea>
                        <button type="submit" >Send <i class="fa fa-paper-plane"></i></button>
                    </form>
                    <div class="map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3650.0981115683703!2d90.42336961405039!3d23.815109984557527!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c64c103a8093%3A0xd660a4f50365294a!2sNorth%20South%20University!5e0!3m2!1sen!2sbd!4v1603700808576!5m2!1sen!2sbd" height="400" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                    </div>
                </div>
                <div class="box">
              <div class="text">
                  <h3><i class="fa fa-comments"></i>COMMUNICATION</h3>
                  <p>Forgeneral quries,inculiding property sales and home rent,please email us at
                  <span>Info@mproperty.com</span>
                </p>
              </div>
              <div class="text">
                <h3><i class="fa fa-life-ring"></i>TECHNICAL SUPPORT</h3>
                <p>We are ready to help!if you have any queries or isues,contact us for support
                <span>01712816319</span>
              </p>
            </div>
            <div class="text">
                <h3><i class="fa fa-map">OTHERS</i></h3>
                <p>Forgeneral quries,inculiding property sales and home rent,please email us at
                <span>Info@mproperty.com</span>
              </p>
            </div>
        </div>
            </div>
        </section>
    
    
        <!-----Footer---------------------->
        <footer>
         <div class="content">
             <div class="box">
                 <h2>WHO WE ARE</h2>
                 <p>You can find your best home here</p>
                 <h3>Trusted by more than 1000+ people</h3>
             </div>
             <div class="box">
                <h2>CONTACT US</h2>
                <h3><i class="fa fa-map-maker">Location</i></h3>
                <p>HOUSE:155, ROAD NO:06, BLOCK:D, BASHUNDHARA,DHAKA</p>
                <h3><i class="fa fa-phone">Phone</i></h3>
                <p>01712816319</p>
                <h3><i class="fa fa-envelope-o">Email</i></h3>
                <p>info@gmail.com</p>
                
            </div>
            <div class="box">
                <h2>LATEST NEWS</h2>
                <h3><i class="fa fa-twitter">Follow us</i></h3>
                <p>you will get all the updates</p>
                <h3><i class="fa fa-facebook">Follow us</i></h3>
                <p>you will get all the updates</p>
            </div>
         </div>
         <div class="row">
        <p>&copy; 2020 Mproperty. All Rights Reserved| Design by <span>Team Mproperty</span></p>
        <div class="social">
            <a href="#"><i class="fab fa-facebook">Facebook</i></a>
            <a href="#"><i class="fab fa-instagram">Instagram</i></a>
            <a href="#"><i class="fab fa-twitter">Twitter</i></a>
            <a href="#"><i class="fab fa-linkedin">Linkedin</i></a>




        </div>
         </div>
        </footer>
        <!----------Register/ Login------------->
        <div class="login-container">
       <i class="fa fa-times" id="btn-close"></i>
       <div class="login-box">
           <form>
               <h2>Login</h2>
               <label for="log-mail">
                   <i class="fa fa-envelope-o"></i>
                   <input type="email" name="mail" id="log-mail" required placeholder="Your Email">
               </label>
               <label for="log-pass">
                <i class="fa fa-lock"></i>
                <input type="password" name="pass" id="log-pass" required placeholder="Your Password">
            </label>
            <label for="chk" class="check">
                <input type="checkbox" name="chk" id="chk">
                Remember me
            </label>
            <button type="submit">Login</button>
            <p>Or login with</p>
            <a href="#" class="btn btn-fb">
                <i class="fa fa-facebook"></i>
                Facebook
            </a>
            <a href="#" class="btn btn-gg">
                <i class="fa fa-google"></i>
                Google
            </a>
            <p>Not a member? <a href="#" class="next-log">Register now</a></p>
           </form>
       </div>

       <div class="login-box hidden" id="res">
        <form>
            <h2>Register</h2>
            <label for="res-user">
                <i class="fas fa-user"></i>
                <input type="text" name="user" id="res-user" required placeholder="User Name">
            </label>
            <label for="res-mail">
             <i class="fa fa-envelope-o"></i>
             <input type="email" name="mail" id="res-mail" required placeholder="Your Email">
         </label>
         <label for="res-pass">
            <i class="fa fa-lock"></i>
            <input type="password" name="pass" id="res-pass" required placeholder="Your Password">
        </label>
        <label for="res-cfpass">
            <i class="fa fa-lock"></i>
            <input type="password" name="cfpass" id="res-cfpass" required placeholder="Confrim Password">
        </label>

         <label for="chk1" class="check">
             <input type="checkbox" name="chk1" id="chk1">
             I accept <span>Terms of User</span>&<span> Privacy Pollicy</span>
         </label>
         <button type="submit">Register</button>
         
         <p>Already have an accounts? <a href="#" class="next-log">Register now</a></p>
        </form>
    </div>
        </div>
        <div class="top-scroll">
            <a href="#">&#11165</a>

        </div>
    </div>

   <script>
   // Login / register----------------------
   const loginMenu = document.querySelector('#logbtn');
   const loginShow = document.querySelector('.login-container');
   const loginClose= document.querySelector('#btn-close');
   loginMenu,addEventListener('click', ()=>{
       loginShow.style.clipPath=`circle(0 at 50% 50%)`;
   })
   btnClose,addEventListener('click', ()=>{
       loginShow.style.clipPath=`circle(0 at 50% 50%)`;
   })
  const btnToggle= document.querySelectorAll('.next-log');
  const resForm = document.querySelector('#res');
  btnToggle.forEach(item=>{
      iteam.addEventListener('click',()=>{
          resForm.classList.toggle('.hidden');
      })
  })

   </script>


</body>
</html>