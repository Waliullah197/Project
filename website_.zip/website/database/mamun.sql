-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2020 at 06:04 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mamun`
--

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `id` int(11) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `type` varchar(1000) NOT NULL,
  `price` varchar(1000) NOT NULL,
  `photo` text,
  `home_size` varchar(1000) DEFAULT NULL,
  `home_bed` varchar(1000) DEFAULT NULL,
  `home_bath` varchar(1000) DEFAULT NULL,
  `home_description` text,
  `home_address` varchar(1000) DEFAULT NULL,
  `land_size` varchar(1000) DEFAULT NULL,
  `land_address` varchar(1000) DEFAULT NULL,
  `land_description` text,
  `office_size` varchar(1000) DEFAULT NULL,
  `office_address` varchar(1000) DEFAULT NULL,
  `office_description` text,
  `phone` varchar(1000) NOT NULL,
  `rent_sell` varchar(1000) NOT NULL,
  `date` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`id`, `title`, `type`, `price`, `photo`, `home_size`, `home_bed`, `home_bath`, `home_description`, `home_address`, `land_size`, `land_address`, `land_description`, `office_size`, `office_address`, `office_description`, `phone`, `rent_sell`, `date`) VALUES
(6, 'Ready flat sell', '1', '250000', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', '1', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(100) NOT NULL,
  `user_role` varchar(10) NOT NULL,
  `created_date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `address`, `phone`, `user_role`, `created_date`) VALUES
(1, 'Michael James', '22@dd.com', '4321', '', '02035142232', '', ''),
(2, 'Edward Solomon', '32@dd.com', '4321', '', '02035142282', '', ''),
(3, 'Wali', 'wali@gmail.com', '123456', '', '01684155305', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `property`
--
ALTER TABLE `property`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
