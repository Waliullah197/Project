<?php $title = "Search"; include('header.php');
include('db.php');
if(isset($_POST['query'])) {
    $inpText=$_POST['query'];
    $query="SELECT * FROM property WHERE location LIKE '%$inpText%'";
    $result = $conn->query($query);
    if($result->num_rows>0) {
        while($row = $result->fetch_assoc()) {
            

?>

<div class="row">
	<div class="col-12">
		<div class="card">
  <h5 class="card-header"><?php echo $row['title']; ?></h5>
  <div class="card-body">
    <h5 class="card-title">Price: BDT <?php echo $row['price']; ?></h5>
    <a href="property.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">View</a>
  </div>
</div>
	</div>
</div>



 <?php       
		}
    }
}



 include('footer.php');?>