<?php $title = "Account"; include('header.php'); include('db.php'); 


$sql = "SELECT * FROM users WHERE id='".$_SESSION["id"]."'";
$result = mysqli_query($conn,$sql);
$count  = mysqli_num_rows($result);
	if($count==1) {
		while($row = mysqli_fetch_assoc($result)) {
		
		
		
?>

<div class="row">
                    
                    <div class="col-12 col-lg-8 offset-lg-2">
						<div class="card text-center">
							<div class="card-body">
								<h4><?php echo $row["name"]; ?></h4>
								
								<p>
									<i class="glyphicon glyphicon-envelope"></i><?php echo $row["email"]; ?>
									<br />
									<i class="glyphicon glyphicon-envelope"></i><?php echo $row["phone"]; ?>
									<br />
									
									<i class="glyphicon glyphicon-gift"></i><?php echo $row["created_date"]; ?></p>
								<!-- Split button -->
                        
							</div>
						</div>
                    </div>
                </div>

<?php }} ?>
<a href="property.php" class="btn btn-block btn-success mt-3 rounded-0 text-uppercase">Add Property</a>
<div class="row">
				<div class="col-12">
					<table class="table table-striped mt-3">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Photo</th>
								<th scope="col">Property Name</th>
								<th scope="col">Price</th>
								<th scope="col">Type</th>
								<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody>
						<?php 
						$sql2 = "SELECT * FROM property";
						$result2 = mysqli_query($conn,$sql2);
						$count2  = mysqli_num_rows($result2);
							if($count2 > 0) {
								while($row2 = mysqli_fetch_assoc($result2)) {
						
						?>
							<tr>
							  <th scope="row">1</th>
							  <td><div style="overflow: hidden; width: 150px; height:50px;"> <img src="images/<?php echo $row2["photo"]; ?>" style="width: 100%;" /> </div> </td>
							  <td><?php echo $row2["title"]; ?></td>
							  <td><?php echo $row2["price"]; ?></td>
							  <td><?php if($row2["type"]==1) {
									echo "Home";
							  } elseif($row2["type"]==2) {
									echo "Office";
							  } else {
									echo "Land";
							  }
								  ?></td>
							  <td><a href="property.php?edit=<?php echo $row2["id"]; ?>" class="btn btn-sm btn-info">Edit</a> <a href="property.php?id=<?php echo $row2["id"]; ?>" class="btn btn-sm btn-success" target="_blank">View</a> <a href="property.php?delete=<?php echo $row2["id"]; ?>" class="btn btn-sm btn-danger">Delete</a></td>
							</tr>
							<?php } }?>
						</tbody>
					</table>
				</div>
			</div>




<?php include('footer.php');?>