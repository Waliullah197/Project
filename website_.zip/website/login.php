<?php $title = "Login"; include('header.php'); include('db.php'); ; 

if(isset($_POST["email"])) {
	$email = $_POST["email"];
	$password = $_POST["password"];
	$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
	$result = mysqli_query($conn,$sql);
	$count  = mysqli_num_rows($result);
	if($count==0) {
		echo "Invalid Username or Password!";
	} else {
		 while($row = mysqli_fetch_assoc($result)) {
		$_SESSION["id"] = $row["id"];
		$_SESSION["email"] = $row["email"];
		$_SESSION["name"] = $row["name"];
		$_SESSION["phone"] = $row["phone"];
		}
		header("Location: account.php");
	}
}






?>
<div class="row py-5">
				<div class="col-12 col-lg-6 offset-lg-3">
					<div class="regback">
						<h2>Login </h2>
						<form action="login.php" method="post">
						  <div class="form-group">
							<label for="exampleInputEmail1">Email address</label>
							<input type="email" class="form-control" name="email">
						  </div>
						  <div class="form-group">
							<label for="exampleInputPassword1">Password</label>
							<input type="password" class="form-control" name="password">
						  </div>
						  <button type="submit" class="rgbtn">Login</button>
						</form>
					</div>
				</div>
			</div>




<?php include('footer.php');?>