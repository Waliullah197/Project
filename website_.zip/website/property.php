<?php $title = "Property"; include('header.php'); include('db.php');

if(isset($_POST['add_property'])) {

	$title = $_POST['title'];
	$type = $_POST['type'];
	$price = $_POST['price'];
	$home_size = $_POST['home_size'];
	$home_bed = $_POST['home_bed'];
	$home_bath = $_POST['home_bath'];
	$home_description = $_POST['home_description'];
	$home_address = $_POST['home_address'];
	$land_size = $_POST['land_size'];
	$land_address = $_POST['land_address'];
	$land_description = $_POST['land_description'];
	$office_size = $_POST['office_size'];
	$office_address = $_POST['office_address'];
	$office_description = $_POST['office_description'];
	$phone = $_POST['phone'];
	$rent_sell = $_POST['rent_sell'];
	$date = $_POST['date'];
	$location = $_POST['location'];
	
	// Access the $_FILES global variable for this specific file being uploaded
// and create local PHP variables from the $_FILES array of information
$fileName = $_FILES["uploaded_file"]["name"]; // The file name
$fileTmpLoc = $_FILES["uploaded_file"]["tmp_name"]; // File in the PHP tmp folder
$fileType = $_FILES["uploaded_file"]["type"]; // The type of file it is
$fileSize = $_FILES["uploaded_file"]["size"]; // File size in bytes
$fileErrorMsg = $_FILES["uploaded_file"]["error"]; // 0 for false... and 1 for true
$fileName = preg_replace('#[^a-z.0-9]#i', '', $fileName); 
$kaboom = explode(".", $fileName); // Split file name into an array using the dot
$fileExt = end($kaboom); // Now target the last array element to get the file extension
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

$newfilename = generateRandomString() . '.png';
$path = "images/" . $newfilename;
// $fileName = time().rand().".".$fileExt;
// START PHP Image Upload Error Handling --------------------------------------------------
if (!$fileTmpLoc) { // if file not chosen
    echo "ERROR: Please browse for a file before clicking the upload button";
    exit();
} else if($fileSize > 5242880) { // if file size is larger than 5 Megabytes
    echo "ERROR: Your file was larger than 5 Megabytes in size.";
    unlink($fileTmpLoc); // Remove the uploaded file from the PHP temp folder
    exit();
} else if (!preg_match("/.(gif|jpg|png)$/i", $fileName) ) {
     // This condition is only if you wish to allow uploading of specific file types    
     echo "ERROR: Your image was not .gif, .jpg, or .png.";
     unlink($fileTmpLoc); // Remove the uploaded file from the PHP temp folder
     exit();
} else if ($fileErrorMsg == 1) { // if file upload error key is equal to 1
    echo "ERROR: An error occured while processing the file. Try again.";
    exit();
}
// END PHP Image Upload Error Handling ----------------------------------------------------
// Place it into your "uploads" folder mow using the move_uploaded_file() function
$moveResult = move_uploaded_file($fileTmpLoc, $path);
// Check to make sure the move result is true before continuing
if ($moveResult != true) {
    echo "ERROR: File not uploaded. Try again.";
    exit();
} 
// Display things to the page so you can see what is happening for testing purposes
echo "The file named <strong>$fileName</strong> uploaded successfuly.<br /><br />";
echo "It is <strong>$fileSize</strong> bytes in size.<br /><br />";
echo "It is an <strong>$fileType</strong> type of file.<br /><br />";
echo "The file extension is <strong>$fileExt</strong><br /><br />";
echo "The Error Message output for this upload is: $fileErrorMsg";
	
$photo = $newfilename;	
	
	
	$sql = "INSERT INTO property (title,type,price,photo,home_size,home_bed,home_bath,home_description,home_address,land_size,land_address,land_description,office_size,office_address,office_description,phone,rent_sell,date,location) VALUES ('$title', '$type', '$price', '$photo', '$home_size', '$home_bed', '$home_bath', '$home_description', '$home_address', '$land_size', '$land_address', '$land_description', '$office_size', '$office_address', '$office_description', '$phone', '$rent_sell', '$date', '$location')";
									if (mysqli_query($conn, $sql)) {
										echo "property added successfully!";
										header("Location: account.php");
									} else {
										echo "Error: " . $sql . "<br>" . mysqli_error($conn);
									}

}
if(isset($_POST['edit_property'])) {
	$getid = $_POST['id'];
	$title = $_POST['title'];
	$type = $_POST['type'];
	$price = $_POST['price'];
	$location = $_POST['location'];
	$home_size = $_POST['home_size'];
	$home_bed = $_POST['home_bed'];
	$home_bath = $_POST['home_bath'];
	$home_description = $_POST['home_description'];
	$home_address = $_POST['home_address'];
	$land_size = $_POST['land_size'];
	$land_address = $_POST['land_address'];
	$land_description = $_POST['land_description'];
	$office_size = $_POST['office_size'];
	$office_address = $_POST['office_address'];
	$office_description = $_POST['office_description'];
	$phone = $_POST['phone'];
	$rent_sell = $_POST['rent_sell'];
	

	
	
	
	$sql2 = "UPDATE property SET 
title = '$title', 
type = '$type', 
price = '$price', location = '$location', 
home_size = '$home_size', 
home_bed = '$home_bed', 
home_bath = '$home_bath', 
home_description = '$home_description', 
home_address = '$home_address', 
land_size = '$land_size', 
land_address = '$land_address', 
land_description = '$land_description', 
office_size = '$office_size', 
office_address = '$office_address', 
office_description = '$office_description', 
phone = '$phone', 
rent_sell = '$rent_sell' WHERE id='$getid'";
	
									if (mysqli_query($conn, $sql2)) {
										echo "property added successfully!";
										header("Location: account.php");
									} else {
										echo "Error: " . $sql2 . "<br>" . mysqli_error($conn);
									}

}


?>
<?php

if(isset($_GET['id'])) {
	$getid = $_GET['id'];
	$sql2 = "SELECT * FROM property WHERE id='$getid'";
	$result2 = mysqli_query($conn,$sql2);
						$count2  = mysqli_num_rows($result2);
							if($count2 > 0) {
								while($row2 = mysqli_fetch_assoc($result2)) {
?>
<div class="row py-5 property">
					<div class="col-12 col-lg-12 my-3">
						<img src="images/<?php echo $row2["photo"]; ?>" class="img-fluid rounded"/>
					</div>
					<div class="col-12 col-lg-12 my-3">
						<h2><?php echo $row2["title"]; ?></h2>
						<h3>BDT <?php echo $row2["price"]; ?></h3>
						<h3>Location: <?php echo $row2["home_address"]; ?></h3>
						<div class="rgbtn text-center my-4">Call: <?php echo $row2["phone"]; ?></div>
						<ul>
							<li>Bedroom: <span><?php echo $row2["home_bed"]; ?></span></li>
							<li>Bathroom: <span><?php echo $row2["home_bath"]; ?></span></li>
							<li>Size: <span><?php echo $row2["home_size"]; ?></span></li>
						</ul>

						<p><?php echo $row2["home_description"]; ?></p>
					</div>
				</div>

<?php } } } elseif(isset($_GET['edit'])) {
	$getid = $_GET['edit'];
	$sql2 = "SELECT * FROM property WHERE id='$getid'";
	$result2 = mysqli_query($conn,$sql2);
						$count2  = mysqli_num_rows($result2);
							if($count2 > 0) {
								while($row2 = mysqli_fetch_assoc($result2)) {
	
	
	
	
	?>

<div class="row py-5">
				<div class="col-12 col-lg-6">
					<h2>Edit Property Image</h2>
					<form action="photo.php" method="post" enctype="multipart/form-data">
						  <div class="form-group">
							<label>Photo</label>
							<div style="overflow: hidden; width: 100%; height:150px;"> <img src="images/<?php echo $row2["photo"]; ?>" style="width: 100%;" /> </div>
							<br>
							<input type="file" class="form-control-file" name="uploaded_file">
						  </div>
						  <input type="hidden" name="id" value="<?php echo $row2["id"]; ?>"/>
						  <input type="submit" name="edit_photo" class="rgbtn" value="EDIT"/>
						</form>
				</div>
				<div class="col-12 col-lg-6">
					<div class="regback">
						<h2>Edit Your Property </h2>
						<form action="property.php" method="post" enctype="multipart/form-data">
						  <div class="form-group">
							<label for="exampleInputEmail1">Title</label>
							<input type="text" class="form-control" name="title" value="<?php echo $row2["title"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Type of property</label>
							<select name="type" class="form-control">
								<option value="1">Home</option>
								<option value="2">Office</option>
								<option value="3">Land</option>
							</select>
						  </div>
						  <div class="form-group">
							<label>Price</label>
							<input type="text" class="form-control" name="price" value="<?php echo $row2["price"]; ?>">
						  </div>
						  <div class="form-group">
							<label>location</label>
							<input type="text" class="form-control" name="location" value="<?php echo $row2["location"]; ?>">
						  </div>
						  
						  <div class="form-group">
							<label>Home Size</label>
							<input type="text" class="form-control" name="home_size" value="<?php echo $row2["home_size"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Home address</label>
							<input type="text" class="form-control" name="home_address" value="<?php echo $row2["home_address"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Home Bed</label>
							<input type="text" class="form-control" name="home_bed" value="<?php echo $row2["home_bed"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Home Bath</label>
							<input type="text" class="form-control" name="home_bath" value="<?php echo $row2["home_bath"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Home Description</label>
							<input type="text" class="form-control" name="home_description" value="<?php echo $row2["home_description"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Land Size</label>
							<input type="text" class="form-control" name="land_size" value="<?php echo $row2["land_size"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Land Address</label>
							<input type="text" class="form-control" name="land_address" value="<?php echo $row2["land_address"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Land Description</label>
							<input type="text" class="form-control" name="land_description" value="<?php echo $row2["land_description"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Office Size</label>
							<input type="text" class="form-control" name="office_size" value="<?php echo $row2["office_size"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Office Address</label>
							<input type="text" class="form-control" name="office_address" value="<?php echo $row2["office_address"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Office Description</label>
							<input type="text" class="form-control" name="office_description" value="<?php echo $row2["office_description"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Phone</label>
							<input type="text" class="form-control" name="phone" value="<?php echo $row2["phone"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Rent or Sell</label>
							<select name="rent_sell" class="form-control">
								<option value="1">For Rent</option>
								<option value="2">For Sell</option>
							</select>
						  </div>
						  
						  <input type="hidden" name="id" value="<?php echo $row2["id"]; ?>"/>
						  <input type="submit" name="edit_property" class="rgbtn" value="EDIT"/>
						</form>
					</div>
				</div>
			</div>

<?php } } } elseif(isset($_GET['delete'])) {
	$getid = $_GET['delete'];
	$sql2 = "DELETE FROM property WHERE id='$getid'";
	$result2 = mysqli_query($conn,$sql2);
						
							if($result2) {
								header("Location: account.php");
							}
} else { ?>
			<div class="row py-5">
				<div class="col-12 col-lg-6 offset-lg-3">
					<div class="regback">
						<h2>Add Your Property </h2>
						<form action="property.php" method="post" enctype="multipart/form-data">
						  <div class="form-group">
							<label for="exampleInputEmail1">Title</label>
							<input type="text" class="form-control" name="title">
						  </div>
						  <div class="form-group">
							<label>Type of property</label>
							<select name="type" class="form-control">
								<option value="1">Home</option>
								<option value="2">Office</option>
								<option value="3">Land</option>
							</select>
						  </div>
						  <div class="form-group">
							<label>Price</label>
							<input type="text" class="form-control" name="price">
						  </div>
						  <div class="form-group">
							<label>location</label>
							<input type="text" class="form-control" name="location">
						  </div>
						  <div class="form-group">
							<label>Photo</label>
							<input type="file" class="form-control-file" name="uploaded_file">
						  </div>
						  <div class="form-group">
							<label>Home Size</label>
							<input type="text" class="form-control" name="home_size">
						  </div>
						  <div class="form-group">
							<label>Home address</label>
							<input type="text" class="form-control" name="home_address">
						  </div>
						  <div class="form-group">
							<label>Home Bed</label>
							<input type="text" class="form-control" name="home_bed">
						  </div>
						  <div class="form-group">
							<label>Home Bath</label>
							<input type="text" class="form-control" name="home_bath">
						  </div>
						  <div class="form-group">
							<label>Home Description</label>
							<input type="text" class="form-control" name="home_description">
						  </div>
						  <div class="form-group">
							<label>Land Size</label>
							<input type="text" class="form-control" name="land_size">
						  </div>
						  <div class="form-group">
							<label>Land Address</label>
							<input type="text" class="form-control" name="land_address">
						  </div>
						  <div class="form-group">
							<label>Land Description</label>
							<input type="text" class="form-control" name="land_description">
						  </div>
						  <div class="form-group">
							<label>Office Size</label>
							<input type="text" class="form-control" name="office_size">
						  </div>
						  <div class="form-group">
							<label>Office Address</label>
							<input type="text" class="form-control" name="office_address">
						  </div>
						  <div class="form-group">
							<label>Office Description</label>
							<input type="text" class="form-control" name="office_description">
						  </div>
						  <div class="form-group">
							<label>Phone</label>
							<input type="text" class="form-control" name="phone" value="<?php echo $_SESSION["phone"]; ?>">
						  </div>
						  <div class="form-group">
							<label>Rent or Sell</label>
							<select name="rent_sell" class="form-control">
								<option value="1">For Rent</option>
								<option value="2">For Sell</option>
							</select>
						  </div>
						  <input type="hidden" name="date" value="<?php echo date("Y-m-d"); ?>">
						  
						  
						  
						  <input type="submit" name="add_property" class="rgbtn" value="Add Property">
						</form>
					</div>
				</div>
			</div>



<?php } include('footer.php');?>